# JRENG! CODING STANDARDS

**Purpose:** This document defines coding standards for LLM agents to follow when generating C++ code. These rules ensure consistency, readability, and maintainability.

---

## CORE PRINCIPLE: DRY (Don't Repeat Yourself)
**Never duplicate code.** Extract common logic into functions, use inheritance, templates, or other abstractions to eliminate repetition.

---

## FORMATTING

### Braces
Always place opening braces on a new line:
```cpp
// WRONG
if (x == 0) {
    foobar();
}

// CORRECT
if (x == 0)
{
    foobar();
}
```

### Spacing

**Operators:**
```cpp
x = 1 + y - 2 * z / 3;  // Space around binary operators
```

**Special operators:**
- Use C++ alternative tokens: `not`, `and`, `or` — NEVER `!`, `&&`, `||`
- `~` preceded by space, not followed: `foo = ~ bar`
- `++` and `--` no spaces: `++i`, `i++`

**Function calls:**
```cpp
foo (x, y);     // Space after comma only
foo (123);      // Space after function name
foo();          // Space after function name
foo[1];         // No space before brackets
```

**Control statements:**
- Blank line before `if`, `for`, `while`, `do` when preceded by another statement
- Blank line after closing brace (unless next line is also a closing brace)

**One-line statements allowed:**
```cpp
if (x == 1) return "one";
if (x == 2) return "two";
```

**Lambdas:**
```cpp
auto myLambda = [] { return 123; };
auto myLambda = [this, &x] (int z) -> float { return x + z; };

auto longerLambda = [] (int x, int y) -> int
{
    // multiple lines
};
```

---

## POINTERS AND REFERENCES

**Asterisk/ampersand placement:**
```cpp
SomeObject* myObject = getAPointer();   // Correct: sticks to type
SomeObject& myObject = getAReference(); // Correct: sticks to type
```

**Multiple pointers:**
```cpp
// WRONG
SomeObject* p1, *p2;

// CORRECT
SomeObject* p1;
SomeObject* p2;
```

**Const placement:**
```cpp
const Thing& t;  // CORRECT: const before type
Thing const& t;  // WRONG
```

---

## TYPE DECLARATIONS

**Templates:**
```cpp
vector<int>
template <typename Type1, typename Type2>  // Use "typename", descriptive names
```

**Line continuation:**
```cpp
// CORRECT: operator at start of continuation line
auto xyz = foo + bar
         + func (123)
         - def + 4321;

// CORRECT: method chaining
auto t = AffineTransform::translation (x, y)
                         .scaled (2.0f)
                         .rotated (0.5f);
```

---

## COMMENTS

**Prefer `//` over `/* */`** for easier block commenting during debugging.

**Content:** the code is the source of truth. A comment can be wrong or stale.

- Write code that a reader understands without comments, per MANIFESTO.md, CODING.md, and NAMES.md.
- A comment gives the why: why a decision was made, why an algorithm was used, why a variable needs to exist. It never repeats what the code does, or how.
- A comment never excuses a contract violation. The contract is not negotiable. The rationale follows from contract adherence.
- A comment stands alone. It never names PLAN.md, RFC.md, SPEC.md, ARCHITECT's direction or rulings, sprint, task, or chat discussion, citations from a session, or agent names.
- Timing: CAROL.md Code Hygiene. Doxygen: `doxygen-writer` skill.

**Alignment:**
```cpp
// CORRECT
/* This is correct
 */

/** This is also correct
 */

// WRONG
/* This is wrong!
*/
```

**Spacing:**
```cpp
// yes!
//no!
```

---

## LITERALS AND CONSTANTS

**Numeric literals:**
```cpp
0xabcdef  // Hex lowercase
0.0       // Double
0.0f      // Float

// AVOID
0.        // No
.1        // No
.1f       // No
```

**Variable initialization:**
Prefer brace initialization over `=`:
```cpp
// CORRECT
int myInteger { 9 };
double sampleRate { 48000.0 };
float gain { 0.5f };

// AVOID
int myInteger = 9;
double sampleRate = 48000.0;
```

**Exception — initializer of the same container type:** use parentheses.
List initialization tries initializer-list constructors first. A JUCE
container (`juce::Array`, `juce::OwnedArray`, …) has a template
`initializer_list` constructor (`juce_Array.h:138`). On the Windows build
(clang-cl), the compiler deduced the element type from the initializer, so
`{ x }` selected that constructor and tried to make a container that holds `x`
as its only element. It did not copy or move `x`, and the build failed.

```cpp
// WRONG — clang-cl selects Array<File> (std::initializer_list<Array<File>>); the build fails
auto descendants { item.findChildFiles (juce::File::findFilesAndDirectories, true) };

// CORRECT — copy or move construction
auto descendants (item.findChildFiles (juce::File::findFilesAndDirectories, true));
```

### Platform macro names

Do not use a Windows SDK macro name as an identifier. The SDK uses `#define`
for these names. The preprocessor replaces the identifier before the compiler
reads it, so the code compiles on macOS and fails on Windows.

| Name | Windows SDK definition |
|---|---|
| `pascal` | `minwindef.h` — `__stdcall` |
| `cdecl` | `minwindef.h` — `_cdecl`, or empty |
| `near`, `far` | `minwindef.h` — empty |
| `NEAR`, `FAR` | `minwindef.h` — `near`, `far` |
| `IN`, `OUT`, `OPTIONAL` | `minwindef.h` — empty |
| `CALLBACK` | `minwindef.h` — `__stdcall` |
| `min`, `max` | `minwindef.h` — function-like macros, unless `NOMINMAX` |
| `small` | `rpcndr.h` — `char` |
| `interface` | `combaseapi.h` — `struct` |
| `ERROR` | `wingdi.h` — `0` |
| `DELETE` | `winnt.h` — `(0x00010000L)` |

```cpp
// WRONG — becomes juce::MemoryBlock __stdcall (...) on Windows
juce::MemoryBlock pascal { static_cast<size_t> (size), true };

// CORRECT
juce::MemoryBlock pascalString { static_cast<size_t> (size), true };
```

**String construction:**
```cpp
String w ("World");              // Best
auto w = "Hello " + w;           // Use implicit conversion
```

---

## NAMING CONVENTIONS

- **Variables:** `myVariableName` (camelCase)
- **Classes:** `MyClassName` (PascalCase)
- **Use descriptive names,** not type-based names
- **Avoid `JUCE_` prefix** (reserved for JUCE library)
- **Enums:** Prefer `enum class`; plain `enum` permitted when required
```cpp
enum class MyEnum
{
    enumValue1 = 0,
    enumValue2 = 1
};
```
- **Template parameters:** Use descriptive names, not `T`
- **No underscores in any variable name.** This includes trailing-underscore constructor
  parameters in member initializer lists. Use a distinct camelCase name.

```cpp
// WRONG
class Object (int parameter_) : parameter (parameter_) {}

// CORRECT
class Object (int newParameter) : parameter (newParameter) {}
```

---

## SCOPE AND OWNERSHIP OF VALUES (MANDATORY)

Before adding any name, constant, or configuration call:

1. **Read the owner first.** The component, LookAndFeel, or framework type that
   consumes the value owns its default and its API. If a default or setter already
   exists there, use it — do not restate it in project code.
2. **Narrowest scope that holds every use.** A value or type used by one function
   lives inside that function (enum, `static constexpr`, lambda-local). It moves to
   class scope only when two members need it, to file scope only when two functions
   need it, to a header only when two translation units need it. Never hoist "for
   tidiness."
3. **Project code configures only the difference.** A registration or config call
   that passes the framework default is dead code. Project constants exist only for
   values that differ from the owner's default and that no data lane (CSS metrics,
   markdown tables, identifiers) already carries.

```cpp
// WRONG — framework default restated in the project, hoisted to file scope
static constexpr float analyzerMinDecibels { -90.0f };   // Analyzer already defaults to -90
…
analyzer->setDecibelRange (analyzerMinDecibels, analyzerMaxDecibels);

// WRONG — single-use enum hoisted out of its only user
enum class VariChild { … };                              // file scope
r.registerConfig<VariComponent> (…, [] (VariComponent* v) { … VariChild::textBox … });

// CORRECT — the owner keeps the default; the enum lives where it is used
r.registerConfig<VariComponent> (…, [] (VariComponent* v)
{
    enum class VariChild { … };
    …
});
```

---

## CONST AND CONSTEXPR

- **Make everything `const` that can be `const`**
- **Use `constexpr` wherever possible** for compile-time evaluation
- **Local variables:** Only mark `const` if it improves readability in longer blocks
- **Function parameters:** Default to `const` for references

---

## OVERRIDE AND VIRTUAL

```cpp
void myFunction() override;        // CORRECT: use override
void myFunction() virtual;         // WRONG: never with override
```

**Always use `noexcept`** where applicable (can improve performance up to 10x).

---

## POINTERS AND NULLPTR

**Null checks:**
```cpp
if (myPointer != nullptr)  // CORRECT: explicit
if (myPointer)             // WRONG: implicit cast

if (myPointer == nullptr)  // CORRECT: explicit
if (! myPointer)           // WRONG: implicit
```

**Use modern casts:**
```cpp
static_cast<float> (x)     // For trivial casts
reinterpret_cast           // For data reinterpretation (see below)
```

**`reinterpret_cast` — legitimate, well-defined use cases:**

| Use case | Standard status |
|---|---|
| `T* → unsigned char* / std::byte*` | Defined by the standard — legal object representation inspection |
| `uintptr_t ↔ pointer round-trips` | Defined when type is sufficiently wide — required for hardware addresses, MMIO, JIT |
| Function pointer ↔ `void*` | `static_cast` cannot do this — implementation-defined but universally supported |

Outside these three cases, `reinterpret_cast` is a red flag. Every other use must be justified at the call site.

**Integer types:**
```cpp
int64_t      // Prefer standard or juce::int64
long long    // Avoid
```

---

## MEMORY MANAGEMENT

**NEVER use raw `new` or `delete`** unless absolutely necessary.

**Prefer:**
1. Stack allocation
2. `std::unique_ptr` or `juce::ScopedPointer`
3. `juce::HeapBlock` for arrays
4. Reference passing over pointer passing

**NEVER:**
- Use `new[]` or `malloc` for C++ arrays
- Use `malloc` or `calloc` at all

**Zero initialization:**
```cpp
MyStruct s = {};           // First choice
zerostruct (s);            // If needed
zeromem (&s, sizeof (s));  // Last resort
memset (&s, 0, sizeof (s)) // AVOID
```

**Never manually manage RAII objects:**
```cpp
// ALL WRONG — RAII objects self-destruct, any manual cleanup in a
// destructor is cargo-cult code
~MyClass()
{
    someObject.reset();     // unique_ptr — redundant
    someObject = nullptr;   // same as reset()
    someMap.clear();        // container — redundant
    someStream.close();     // stream — redundant
}

// CORRECT
~MyClass() = default;
```

RAII is unconditional. The object's own destructor is the cleanup. Manual
intervention signals distrust of the type system and pollutes the codebase.

---

## OWNERSHIP

**Pass ownership with `std::unique_ptr`**

**Smart pointers:**
- Prefer `std::unique_ptr` over `juce::ScopedPointer` (newer code)
- JUCE codebase may still use `juce::ScopedPointer` (legacy)

**No non-owning naked pointers as members:**
```cpp
// WRONG — raw pointer to sibling or parent object
class Editor
{
    Processor* processor;  // non-owning, lifetime untracked, unenforceable
};

// CORRECT — inject at the call site, never store
void Editor::update (Processor& processor)
{
    processor.doSomething();
}
```

Non-owning naked pointers stored as members are a lifetime contract written in
invisible ink. Ownership is not modeled, lifetime is not enforced, and the
compiler cannot help. Redesign so the dependency is passed at the call site
and never stored.

---

## STRING PASSING

Choose based on use case:

```cpp
void foo (const String&);  // General purpose, read-only
void foo (String);         // Will copy anyway
void foo (String&&);       // Move semantics, modify/store
void foo (StringRef);      // Only need basic string operations
```

**Rules:**
- If function will store or move: `String` or `String&&`
- If only basic operations needed: `StringRef` (avoids String object creation)
- Otherwise: `const String&`

---

## CLASS DESIGN

**Use `struct` for data-only types** (saves `public:` line)

**Inheritance format:**
```cpp
class Thing : public Foo,
              private Bar
{
```

**Non-copyable classes:**
```cpp
Foo (const Foo&) = delete;
Foo& operator= (const Foo&) = delete;

// Or use macro
JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MyClass)
```

**Constructors:**
- Mark single-argument constructors `explicit` unless implicit conversion is intended
- Consider what implicit conversions you allow

**No `friend` declarations:**
```cpp
// WRONG — exposes all private members, signals broken API boundary
class Processor
{
    friend class Editor;
};
```

`friend` is encapsulation bypass. If class A needs class B's internals,
redesign B's public API. `friend` is forbidden.

---

## STRUCT DISCIPLINE (MANDATORY)

### No local struct definitions inside function bodies

```cpp
// WRONG — struct deferred to point of use, logic drives type definition
void renderGlyphs (...)
{
    struct GlyphQuad { float x, y, w, h; /* ... */ };
    std::vector<GlyphQuad> quads;
    // ...
}

// CORRECT — struct declared at class scope or dedicated header before use
void renderGlyphs (...)
{
    std::vector<GlyphQuad> quads;
    // ...
}
```

A struct defined inside a function body is evidence that data design was deferred to the moment of use. Data structures dictate business logic — not the reverse. A locally-scoped struct cannot be shared across call sites, tested independently, or evolved without touching the function. It is a workaround with a type name.

`GlyphQuad` above breaks a second rule. Its fields are already in the Model at the same type, thus it is also a fake carrier. A move of the definition to class scope does not correct this. Refer to *No fake-carrier structs*.

**Rule:** All `struct` and `class` definitions belong at class scope, file-local (`static`) scope, or a dedicated header. No struct definitions inside function or method bodies.

---

### No near-duplicate struct proliferation

```cpp
// WRONG — identical layout, two names
struct GlyphFrameVB
{
    VkBuffer vertexBuffer { VK_NULL_HANDLE };
    VmaAllocation vertexAlloc { VK_NULL_HANDLE };
    void* vertexMapped { nullptr };
    VkBuffer indexBuffer { VK_NULL_HANDLE };
    VmaAllocation indexAlloc { VK_NULL_HANDLE };
    void* indexMapped { nullptr };
    int usedVertices { 0 };
    int usedIndices { 0 };
    int capacityVertices { 0 };
    int capacityIndices { 0 };
};

struct PathFrameVB   // identical layout — forbidden
{
    VkBuffer vertexBuffer { VK_NULL_HANDLE };
    VmaAllocation vertexAlloc { VK_NULL_HANDLE };
    void* vertexMapped { nullptr };
    VkBuffer indexBuffer { VK_NULL_HANDLE };
    VmaAllocation indexAlloc { VK_NULL_HANDLE };
    void* indexMapped { nullptr };
    int usedVertices { 0 };
    int usedIndices { 0 };
    int capacityVertices { 0 };
    int capacityIndices { 0 };
};

// CORRECT — one type, two members
struct FrameVB
{
    VkBuffer vertexBuffer { VK_NULL_HANDLE };
    VmaAllocation vertexAlloc { VK_NULL_HANDLE };
    void* vertexMapped { nullptr };
    VkBuffer indexBuffer { VK_NULL_HANDLE };
    VmaAllocation indexAlloc { VK_NULL_HANDLE };
    void* indexMapped { nullptr };
    int usedVertices { 0 };
    int usedIndices { 0 };
    int capacityVertices { 0 };
    int capacityIndices { 0 };
};

FrameVB glyphVB;
FrameVB pathVB;
```

Two structs sharing the same field layout are not two concepts — they are one concept with two owners. Each proliferated variant is a DRY violation and a SSOT violation. Bugs must be fixed N times; every new use-case adds variant N+1. If parameterization is needed, use a template. Never add a near-duplicate struct — design the type once, name it for the concept, reuse everywhere.

**Rule:** If two or more structs share the same field layout pattern, they are the same type. Unify them. Never add a near-duplicate struct variant.

---

### No fake-carrier structs

The Model is the complete AST. It contains value data. A struct that holds again what
the Model holds gives no capability. It is a temporary container with a type name.

```cpp
// WRONG — fake carrier: each field is already in the Model at the same type
struct GlyphQuad
{
    float x, y, w, h;
};

// CORRECT — materialisation: gives a capability that value data does not have
struct AttributeGraphics
{
    juce::Path path;
    juce::Rectangle<float> bounds;
};
```

**The test:** What operation can this type do that value data cannot do? If the answer
is a capability, the type is a materialisation. Capabilities are draw, hit-test,
transform, and measure. If the answer is *"it holds values together for transfer"*, the
type is a fake carrier.

**The structural check:** If each field is already in the Model with the same type, the
type materialises nothing.

A struct is a design decision. A struct is not a convenience. Do not make a struct to
move values between call sites. Do not use prior patterns to make a struct for
convenience. This always makes a fake carrier and is a failure.

A stateful runtime object (a `Component` with geometry, a `Component` with
`LookAndFeel`) is the materialisation itself — it must not also carry a shadow copy of
the Model metadata (`x`, `y`, `w`, `h`, colour) it materialises from. Refer to
MANIFESTO **E** — Materialisation of Concrete Objects.

**Rule:** A struct must give a capability that the Model's value data does not have.
A struct that only carries data is forbidden. Refer to MANIFESTO **E** —
Materialisation of Concrete Objects.

---

## NAMESPACES

**NO anonymous namespaces allowed:**
```cpp
// WRONG
namespace
{
    void helperFunction();
    constexpr int numBufferedEvents { 16 };
}

// CORRECT: use named namespace or static linkage
static void helperFunction();
static constexpr int numBufferedEvents { 16 };
```

**Rationale:**
- Anonymous namespaces hide symbols from tooling, debuggers, and grep-based searches
- They create implicit "private" scopes that fragment the reader's mental model
- Translation-unit-local symbols should be explicit — use `static` linkage, which is visible and greppable
- Named entities survive refactoring across files; anonymous ones silently die or collide

**NO `namespace detail` (or equivalent implementation-hiding namespaces) allowed:**
```cpp
// WRONG
namespace myLibrary
{
    namespace detail
    {
        template <typename T>
        struct HelperImpl { ... };
    }

    template <typename T>
    using Helper = detail::HelperImpl<T>;
}

// CORRECT: place implementation at proper encapsulation boundary
namespace myLibrary
{
    template <typename T>
    struct Helper { ... };
}
```

**Rationale:**
- `namespace detail` is a convention borrowed from header-only libraries to fake private members. It signals "I know this should be encapsulated but I couldn't figure out where" — a design smell, not a tool.
- Real encapsulation belongs in class `private:` sections, separate translation units, or `static` file-local symbols. Use those.
- `detail` namespaces fragment ownership: readers must chase nested namespaces to find what a type actually does, and tooling loses its grip on intent
- BLESSED principle — **Encapsulation**: one responsibility, explicit boundaries, tell don't ask. `detail` violates all three.

If something truly needs to be "hidden" from the public API, it belongs in:
1. A class `private:` section
2. A separate `.cpp` file with `static` linkage
3. A PIMPL idiom with forward-declared implementation class

None of those require `namespace detail`.

---

## CONTROL FLOW

**No bail-out guards — use positive nesting and assert. Result returns are correct and preferred.**
```cpp
// WRONG: bail-out guard — skips work, hides precondition
if (not foobar())
    return;
doSomething();

// CORRECT: assert precondition, positive nesting
assert(foobar() and "precondition: foobar must be valid");
doSomething();

// CORRECT: positive nested check
if (foobar())
{
    doSomething();
}

// CORRECT: result returns — answer determined at that point
int findFirst (const Array<Item>& items, const Query& q)
{
    for (int i = 0; i < items.size(); ++i)
        if (items.at (i).matches (q)) return i;   // answer found — done

    return -1;
}

float applyScale (float x, float threshold, float high, float low)
{
    if (x > threshold) return x * high;   // branch result — done
    return x * low;
}
```

**Narrow pointer scope:**
```cpp
// WRONG: wide scope increases null-pointer risk
auto* f = getFoo();
if (f != nullptr)
    f->doSomething();
// ...lots of code...
f->doSomething();  // Potential null dereference

// CORRECT: narrow scope
if (auto* f = getFoo())
    f->doSomething();
// f out of scope, impossible to misuse
```

---

## MISCELLANEOUS

**NULL:**
```cpp
nullptr  // CORRECT
NULL     // WRONG
0        // WRONG
0L       // VERY WRONG
```

**String literals:**
- Use plain C++ string literals: `"Hello"`
- For Unicode: use `CharPointer_UTF8` or Projucer tool

**Macros:**
- `#undef` after use when possible

**Increment operators:**
```cpp
for (int i = 0; i < 10; ++i)  // Pre-increment preferred
```

---

## HEADER DISCIPLINE (MANDATORY)

### No Forward Declarations

```cpp
// WRONG — forward declarations are symptoms of bad design, strictly forbidden
class SomeComponent;

class MyComponent : public juce::Component
{
    SomeComponent* owner;  // avoid
};
```

**Rationale:** Forward declarations hide dependencies, obscure ownership, and mask include cycles. If you need the type — include the header. If the header is expensive, the design is wrong, not the include.

---

### No Redundant STL Includes

Project-level headers must not explicitly include STL types — `JuceHeader.h` already includes them transitively.

```cpp
// WRONG — JuceHeader.h already provides all STL types
#include "MyProcessor.h"
#include <vector>
#include <string>

class MyComponent : public juce::Component
{
    std::vector<float> data;  // available via JuceHeader.h transitively
};

// CORRECT — trust the transitive include
#include "MyProcessor.h"

class MyComponent : public juce::Component
{
    std::vector<float> data;
};
```

**Rationale:** Explicit STL re-inclusion is redundant, masks include depth, and slows compilation.

---

### No Includes in Submodule Headers or Source Files

A submodule's `.h` and `.cpp` files must include **nothing** — zero includes. Platform-specific headers are the only exception.

```cpp
// WRONG — jam_graphics.h includes its own detail files
#include "detail/jam_cell.h"             // forbidden
#include <cstdint>                       // forbidden
#include "fonts/font/glyph/jam_atlas.h"   // forbidden
```

**Correct pattern — all includes at topmost module header:**

```cpp
// jam_graphics.h — TOPMOST, includes only here
#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <jam_core/jam_core.h>           // jam_core's topmost header only
#include "detail/jam_cell.h"             // detail files included HERE
#include "detail/jam_cell_point.h"       // — not in the detail files themselves
// no other includes in this file

// jam_cell.h — SUBMODULE, zero includes
#pragma once
// — no includes, no forward declares, no STL

// jam_cell.cpp — SUBMODULE, zero includes
// — no includes
```

**Platform-specific exception (.mm / .m files):**

```cpp
// jam_background_blur.mm — platform-specific submodule
#if JUCE_MAC
#include <dlfcn.h>              // platform header — allowed
#import <Cocoa/Cocoa.h>         // Obj-C framework — allowed
// — no other includes
#endif
```

**Rationale:** Single inclusion point at the module definition header enforces clear dependency chains. Submodules are atomic units with no coupling to their containing module's internals. Platform/OS headers are the only exception — required for native API access in `.mm`/`.m` files.

---

### No Redundant TU Includes

A translation unit (`.cpp`) should include only what its declarations require.

```cpp
// WRONG — TU includes headers it does not use
#include "MyHeader.h"
#include "UnusedHeader.h"
```

**Rationale:** Unnecessary includes extend build graphs, slow compiles, and create fragile coupling.

---

## TEMPLATE, CONSTEXPR, AND TRANSLATION UNIT PLACEMENT (MANDATORY)

Applies to modular C++17 libraries of any size (JUCE-scale, JAM/KANJUT/CIUM). This
section is the single source for file placement. LANGUAGE.md refers to it.

ARCHITECT's ruling, verbatim:

> *"PORTABILITY against COMPILE TIME. it does not matter, trivial vs non trivial. a single
> header can contains thousands of LOC, for portability."*
>
> *"a split cpp is preferable to reduce DUPLICATION of inclusion at build time, hence SSOT
> object COMPILE time is the the FIRST and FOREMOST PRIORITY. Compile time SHOULD NEVER
> slowed down by redundant headers inclusion. Single Source of Truth of TU do reduce
> compile time, as FASTEST time to compile is NON-Negotiable, MANDATORY"*
>
> *"the most important against the consideration of the above is CONSISTENCY. split?
> split ALL CORRECTLY. NEVER POLLUTE codebase with scattered cpp with small
> implementation to statisfy 300-30-3 GUIDE. Guide to rethink the design. GUIDE
> adherence isnt about the number, but CORRECT MENTAL MODEL DESIGN BY CONTRACT."*

### The trade-off: portability against compile time

A function body in a header compiles again in each translation unit that includes the
header. In the JUCE module system, every consumer translation unit includes the module
header, and through it every submodule header. A body in a `.cpp` compiles one time, in
the module's unity `.cpp`.

The size of a body does not decide its placement. A trivial body and a non-trivial body
follow the same rule.

### Priorities, in order

1. **Compile time.** Compile time is the first priority and is not negotiable. A
   non-template body goes to the object's `.cpp`, so that it compiles one time. The
   object's `.cpp` is the single source of its implementation.
2. **Consistency.** An object is split completely, or it is not split. One object is one
   header and one `.cpp`. Never put the member bodies of one object in two or more
   `.cpp` files. Never make a small `.cpp` to meet 300/30/3. A threshold crossing tells
   you to rethink the design: decompose a multi-responsibility object into objects, and
   each object is again one header and one `.cpp`.
3. **Portability.** An object can be header-only, of any size, only when portability is
   its purpose: a drop-in header with no build-graph wiring. In a module, the module
   gives portability, so a module object is split.

### What stays in the header
- Class, function, and variable templates
- `constexpr` functions and variables (including `static constexpr`)
- Concepts, requires-clauses, and constraints in overload resolution
- Type traits and metafunctions
- Code-generated `static constexpr` / `static inline` surface
- Declarations of everything else

### What goes to the object's `.cpp`
- Every non-template member function body, whatever its size
- Every non-template free function
- Static data with dynamic (non-`constexpr`) initialization
- An explicit instantiation for each member of a closed set of template arguments,
  when the template definition is in the `.cpp`

### Decision table

| Construct | Placement |
|---|---|
| Template (class/function) | Header |
| `constexpr` / `static constexpr` | Header |
| Non-template member function body | The object's one `.cpp` |
| Non-template free function | The object's one `.cpp` |
| Code-generated pure constexpr/inline | Header |
| Closed set of template instantiations | Definition and explicit instantiations in the object's `.cpp` |
| Header-only object whose purpose is portability | Header |

**Rule:** one object, one translation unit. A non-template body is in the object's
`.cpp`, whatever its size. The member bodies of one object are never in two or more
`.cpp` files.

---

## PASS BY VALUE VS REFERENCE

**Pass by value for small types:**
- `Point`, `Time`, `RelativeTime`, `Colour`
- `Identifier`, `ModifierKeys`, `JustificationType`
- `Range`, `PixelRGB`, `PixelARGB`, `Rectangle`

**Pass by `const` reference for:**
- Large objects (`Array`, `String`, complex types)
- When copy constructor is expensive

**Reason:** Pass-by-value enables better compiler optimizations for small types.

---

## STANDARD LIBRARY

**Math functions:**
```cpp
std::abs, std::sqrt, std::sin, std::cos, std::pow  // CORRECT
fabs, sqrtf, powf                                  // WRONG
```

**Integer types:**
```cpp
int8, uint8, int16, uint16, int32, uint32, int64, uint64  // JUCE types
std::uint32_t, std::int64_t                               // Also acceptable
unsigned int                                              // Explicit
unsigned                                                  // AVOID alone
```

**Indexes:**
- JUCE uses `int` for array indices (not `size_t`)
- Aware of mismatch with STL conventions

---

## CONTAINERS AND ARRAY ACCESS

**Use `.at()` for indexed access on containers that provide it (STL containers). For containers without `.at()`, use the container's own bounds-checked accessor.**

```cpp
// CORRECT: Bounds-checked access (Fail Fast principle)
std::array<int, 4> arr {1, 2, 3, 4};
auto value = arr.at (2);           // Throws std::out_of_range if invalid

std::vector<int> vec {1, 2, 3};
auto value = vec.at (1);           // Bounds-checked

// WRONG: Unchecked access (Undefined Behavior risk)
auto value = arr[2];               // UB if index invalid
auto value = vec[1];               // UB if index invalid
```

**Rationale:**
- ✅ **Fail Fast:** Invalid index throws immediately with stack trace
- ✅ **Semantic Correctness:** Signals "runtime index, validate it"
- ✅ **Zero UB Risk:** Prevents silent memory corruption
- ✅ **Debuggability:** Exception provides exact location of error
- ✅ **Performance:** Negligible cost (~1 branch, perfect prediction for small containers)

**Exception:** Only use `[]` when:
- Index is a compile-time constant AND you've verified it's in bounds
- You're in a proven hot path where profiling shows `.at()` is the bottleneck (rare!)
- In such cases, add a comment justifying the choice

**Range-based loops:**
Prefer range-for when you don't need the index:
```cpp
// BEST: No index needed, inherently safe
for (auto& element : container)
    element.process();

// ACCEPTABLE: Need index, use .at()
for (size_t i = 0; i < container.size(); ++i)
    container.at (i).process();

// AVOID: Unchecked access
for (size_t i = 0; i < container.size(); ++i)
    container[i].process();  // UB risk if size changes
```

---

## AUTO KEYWORD

**Use `auto` when type is obvious from RHS:**
```cpp
auto x = 0.0f;                    // OK: clearly float
auto x = 0.0;                     // OK: clearly double
auto x = thisReturnsABool();      // OK: function name indicates type
auto someResult = getResult();    // OK: expression

// AVOID when ambiguous:
auto x = 0;                       // Bad: could be int, unsigned, int64, etc.

// Explicit when helpful:
for (int i = 0; i < someNumber; ++i)  // Clear: signed int
bool someCondition = false;           // Clear: bool
```

---

## STRUCTURED BINDINGS

Never access pair results via `.first` / `.second` at any level — including dereferenced
map iterators. Chain structured bindings all the way through.
All binding names must be descriptive. `_` and `it` are forbidden.

```cpp
// WRONG
validators.try_emplace (treeType).first->second.insert_or_assign (...);
auto [it, _] = validators.try_emplace (treeType);  // it and _ forbidden
it->second.insert_or_assign (...);

// CORRECT
auto [treeEntry, inserted] = validators.try_emplace (treeType);
auto& [treeKey, treeValidators] = *treeEntry;
treeValidators.insert_or_assign (propertyName, std::move (validator));
```

---

## CRITICAL RULES (MANDATORY)

- **Aggregate (brace) initialization is ALWAYS preferred** over copy assignment: `int x { 0 };` not `int x = 0;` — except when the initializer is the same container type: `auto files (getFiles());`, never `auto files { getFiles() };`
- **No Windows SDK macro names as identifiers** — no name in the *Platform macro names* table.
- **No bail-out guards.** Preconditions use an assert (STL, JUCE, or project-specific) — NEVER `if (not valid) return;`. Result returns (value determined at that point) are correct and preferred.
- **ALWAYS use nested positive checks:** `if (valid) { if (ready) { doWork(); } }` — NEVER `if (not valid) return;`
- **No `else` after `return`.** A branch that returns ends the branch. The code after it is the other path.
- **Use `.at()` for container access where the container provides it** — NEVER raw `[]` when a bounds-checked accessor exists. Fail Fast principle: invalid index throws immediately.
- **Use C++ alternative tokens:** `not`, `and`, `or` — NEVER `!`, `&&`, `||`
- **NO anonymous namespaces.** Use `static` linkage for translation-unit-local symbols.
- **NO `namespace detail` (or equivalent implementation-hiding namespaces).** Use class `private:`, separate `.cpp` with `static`, or PIMPL.
- **No underscores in any variable name** — including trailing-underscore constructor parameters.
- **Structured bindings for all pair/tuple results** — chain through dereferences, all names descriptive, `_` and `it` forbidden.
- **Never manually manage RAII objects in destructors** — `.reset()`, `= nullptr`, `.clear()`, `.close()`, or any equivalent. RAII is not opt-in.
- **No non-owning naked pointers as members.** Pass dependencies at the call site — never store them.
- **No `friend` declarations.** Redesign the public API instead.
- **No `DBG` for diagnostics** — use `debug::Log` exclusively. `DBG` is forbidden.
- **No local struct definitions inside function bodies** — data structures are SSOT; define at class scope, file-local `static`, or a dedicated header — never inside a function.
- **No near-duplicate struct proliferation** — identical or near-identical field layouts must be unified into one named type. DRY applies to type definitions.
- **Consume the event payload.** A listener that receives WHICH child/property changed and re-derives it by walking/diffing state is forbidden — react to exactly what the event delivered.
- **No identifier latitude in delegation.** Agents introduce ZERO names not verbatim in their task prompt — a name missing from the prompt is an unratified decision, and the task output is rejected, not amended.
- **Use the framework API fully.** Use the project's in-house framework first — JAM, KANJUT, or CIUM, whichever the project is built on — then its dependency framework (e.g. JUCE) as the building block beneath it. Do not write again a behavior that the framework supplies. This is a blocking violation. Do not do manual arithmetic when a framework API exists — a resource registry that assigns and releases its own identity (index, handle, slot) is the framework API; a hand-computed offset or index next to it is the violation.
- **Owner first, narrowest scope, configure only the difference.** Read the consuming type for an existing default or API before adding any name or value; place what is new in the smallest scope that holds every use; project code never restates a framework default.
- **No `==` / `!=` on strings.** A string compared with `==` is a branch on text. Dispatch by key instead (`Function::Map`, `HashMap`, `Bimap`, `juce::Identifier` equality — an Identifier compare is a pointer compare, not a string compare). Where a genuine text comparison is unavoidable, use `juce::String::compare (…) == 0`; a chain of more than three text tests is a lookup table, never `if`/`else if`.
- **Uniform signature in the type.** A type-erased callable map (`jam::Function::Map<Key, ReturnType>`) is only for entries whose argument lists differ. When every entry has the same signature, declare that signature in the type: `jam::Function::Map<juce::Identifier, void (juce::ValueTree&)>`. `add` then deduces the signature, and no call site writes an explicit template argument. `events.add<juce::ValueTree&> (key, …)` on a map whose every entry takes `juce::ValueTree&` is the violation.
- **`apply` takes a callable; a write is `set`.** A function named `apply…` has a callable parameter that its body calls (`applyFunctionRecursively`, `applyToRecords`). A function with no callable parameter is never `apply…`. A function that writes onto a target is `set…`, whatever its body does. Refer to NAMES.md Rule 1, Verb Contract.
- **No out-parameters.** Return the value. A getter is `const` and takes no out-parameter. The one exception is a value replacement in place — `void process (double& sample)`.
- **No fake-carrier structs.** A struct must give a capability that the Model's value data does not have. A struct that only carries data is forbidden.
- **One object, one translation unit.** Templates and `constexpr` stay in the header. Every non-template body, whatever its size, is in the object's one `.cpp` (compile time first). Never put one object's bodies in two or more `.cpp` files (consistency). Header-only only when portability is the object's purpose.
- **Deadline threads.** A thread with a hard deadline, such as the audio thread or a clock thread, does not allocate, lock, wait, or make a blocking call. This applies to creation and to transit. The owner sizes every buffer of that thread in `prepare`, off the deadline thread. Refer to MANIFESTO **E** — Complete at Creation.

---

## DOXYGEN DISCIPLINE (MANDATORY)

The `doxygen-writer` skill is the only source of the doxygen rules.

---

## DIAGNOSTICS (MANDATORY)

**`DBG` is forbidden** for diagnostic instrumentation — it is a JUCE macro that bypasses the structured log channel and leaves no file-based trace.

**Use `debug::Log` exclusively** — each framework provides it in its own namespace.

Diagnostic instrumentation is ephemeral — all log statements added during investigation are removed within the same sprint. See ODE.md §VI.

---

**Note:** These standards prioritize readability and safety. When in doubt, prefer explicitness over brevity.
