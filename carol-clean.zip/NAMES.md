# Philosophical Framework for Naming in Code

## Preamble

These rules set boundaries to reduce cognitive load, improve readability, lower debugging complexity, and prevent unnecessary technical debt.

They form a holistic approach to naming—meant to guide consistent reasoning, not to cover every edge case or be applied selectively for convenience.

They are tools, not laws: reliable in most situations, but not universally applicable. When a rare case genuinely requires breaking a rule, it should be a deliberate exception, not an accident.

---

## Rule -1 — No Improvisation

**Principle:**
A name, type, method, or pattern comes from an established family. No agent asks ARCHITECT to ratify a name. The agent checks the name itself:

1. The name states the intent accurately (Rule 3).
2. The name joins its family: the nearest set, then the module, then the framework (Rule 5).
3. The method that carries the name holds the CONTRACT (MANIFESTO.md, CODING.md).
4. The name follows every rule in this document.

All four checks pass → use the name and execute. One check fails → the design is wrong. Correct the design, not only the name.

**Rationale:**
Naming is architecture. A name is not a style preference. A name states the mental model, sometimes implicitly and sometimes explicitly. A new name creates a new concept in the system's vocabulary — it shapes how every future reader understands the domain. Improvised names during implementation drift from the architectural intent and create inconsistency that compounds. A wrong name is a symptom of a wrong mental model. It can show that the whole design is wrong.

**A request for ratification is itself a finding.**
The established pattern of the codebase is optimistic, deterministic, direct, and
unambiguous. It uses a fixed verb set (Rule 1, Verb Contract). A name that does not come
from an existing family is evidence of foreign semantics: a new pattern, a hack, or a
patch that diverged from the contract. This is not a question about a name. Correct the
implementation, and state the correction in the report. Do not ask for ratification of
the symptom. A request for ratification is a request to accept a contract violation.

**JUCE is the fallback family.** The in-house framework (JAM, KANJUT, CIUM) comes first.
JUCE is the root of each in-house framework. When the in-house codebase has no family
for the concept, the JUCE family is the pattern. Both codebases hold millions of lines.
"The codebase has no pattern" is not a finding until a read of both codebases shows it.

**Exceptions.** Only two cases permit a name outside an established family:

1. A domain-specific term — the vocabulary of the problem domain.
2. Rarely, a genuinely new pattern: neither the in-house codebase nor JUCE implements
   the domain or the pattern yet. Cite the reads of both codebases.

Neither exception needs ratification. Cite the read and execute.

---

## Rule 0 — Use English

**Principle:**  
All names in code must be written in English.

**Rationale:**  
Using a single language removes unnecessary context-switching. Almost all programming tools, libraries, and documentation are written in English, so using English names keeps the codebase uniform and easier to read. It also ensures that everyone reading the code interprets the same meaning without translation effort.

---

## Rule 1 — Word classes must match their role

**Principle:**  
Use nouns for things, verbs for actions. The grammatical form of the name must reflect what the construct does in the program.

**Rationale:**  
Developers write code, and every line of code becomes a potential liability: it may break, it may hide bugs, and someone will eventually need to understand it. The only protection we have against that future uncertainty is readability. If you cannot read a piece of code clearly, you will not understand it. If you cannot understand it, you will not be able to fix it.

Using nouns for classes, structs, and variables—and verbs for functions—is aligned with the way we naturally think and communicate. It makes code read more like a structured sentence rather than a puzzle. This reduces mental effort and makes the intent of each construct immediately obvious.

**Examples:**

Classes and variables use nouns:
```cpp
class Manager;
class ProcessorChain;
struct Descriptor;
int panelHeight;
juce::File presetDirectory;
```

Functions use verbs:
```cpp
void buildInterface();
void setImages();
bool isValidParameterID();
juce::String getProductName();
```

Booleans prefix verbs before nouns or use adjectives:
```cpp
bool isUsingWhitespace;
bool isPresetDirty;
bool shouldPromptLicense;
bool isEvaluating;
```

**Singular vs Plural:**
```cpp
struct Descriptor;
// Singular. An object structure that contains information describing data,
// used at compile-time or runtime.

using Descriptors = std::unordered_map<juce::String, Descriptor>;
// Plural. A container that holds multiple Descriptor objects indexed by ID.
```

**Verb Contract:**

A verb prefix is a contract about what the call does to the world, not a decoration.
The codebase's verb set is fixed and each verb means exactly one thing:

The verb set is optimistic and deterministic. A verb states what the call does. A verb
does not state what the call defends against (MANIFESTO **D**). A verb that is
uncertain, that retries, or that admits the precondition can be false is foreign to this
codebase (Rule 6).

| Verb | Contract |
|---|---|
| `get` | Returns the object. Does not store, does not mutate a container. |
| `add` | Inserts into a container. The container is the subject. |
| `set` | Writes onto a target: a variable, a member, a container slot, a tree, a component, a stream. The name states the result on the target, not the steps. The body can loop, add, remove, insert, or call other functions (`setAppearance`, `setBypassed`, `setPanelHeight`). |
| `is` / `has` | Answers a question. Returns bool, changes nothing. |
| `apply` | Takes a callable as a parameter and calls it: on each element, on each match, or on a tree (`applyFunctionRecursively`, `applyToRecords`, `applyToComponentRows`). |
| `getOrCreate` | Returns the object, creating it when absent — the side effect is in the name. |

**`set` or `apply` — the test.** Read the signature. A callable parameter that the body
calls → `apply`. No callable parameter → never `apply`. A function that writes onto a
target is `set`, whatever its body does.

```cpp
// WRONG — no callable parameter
void applyFlexGap (juce::FlexBox& flexBox, float gap);
void applyWinsize (TerminalWinsize newWinsize, TerminalBuffer& terminalBuffer);

// CORRECT — writes onto the target
void setFlexGap (juce::FlexBox& flexBox, float gap);
void setWinsize (TerminalWinsize newWinsize, TerminalBuffer& terminalBuffer);

// CORRECT — takes a callable and calls it
template <typename Function>
void applyToRecords (const Document& document, const Function& function);
```

A unit that both computes and stores is two units. Split it: `get` returns, the caller
`add`s. When splitting produces a one-line call site, that is the correct shape — not a
reason to fuse the verbs.

```cpp
// WRONG — get that stores
static juce::String getSvg (const Array<Token>&, Document& element, int& index);

// CORRECT — get returns, caller adds
static juce::String getSvg (const Array<Token>&, CharPointerType source, int& index, int& offset);
element.add<juce::String> (Id::svg, getSvg (tokens, source, index, offset));

// CORRECT — add is named for the container it feeds, returns what the caller needs to advance
static int addToken (kuassa::Array<Token>& tokens, CharPointerType cursor, Token::Type segmentType);
```

---

## Rule 2 — Construct expression without data type statement

**Principle:**  
A name must express its role without explicitly using the data type itself.

**Rationale:**  
Type information is already enforced by the compiler and visible in modern IDEs. Encoding types into names adds noise without adding meaning. The name should describe *what* the construct represents in the domain, not *how* it's stored in memory. This keeps names focused on intent and prevents names from becoming outdated when types change during refactoring.

**Examples:**

**Bad:**
```cpp
int filesInt;
// filesInt tells the reader the type, not the meaning.

class FileMgrClass;
// FileMgrClass redundantly names the construct instead of expressing its purpose.

juce::StringArray choicesArray;
// "Array" suffix duplicates type information already visible in IDE.

std::unique_ptr<juce::XmlElement> xmlPtr;
// "Ptr" suffix is redundant—the type already indicates it's a pointer.
```

**Good:**
```cpp
int panelHeight;
// panelHeight clearly communicates it represents a vertical measurement—
// readers naturally expect this to be an integer without being told.

class Manager;
// Manager conveys the idea of a class responsible for coordinating operations,
// without needing to append "Class" or encode its type.

juce::StringArray choices;
// "choices" describes the semantic content, not the container type.

std::unique_ptr<juce::XmlElement> layout;
// "layout" describes what the data represents in the domain.
```

**No kind prefix.** A prefix that states what kind of construct a name is — `k` for a
constant, `m_` for a member, `g_` for a global, `s_` for a static — is a type statement.
The declaration already states it: `constexpr`, the class scope, `static`.

```cpp
// WRONG
static constexpr int kBufferedEvents { 16 };
int m_panelHeight;

// CORRECT
static constexpr int numBufferedEvents { 16 };
int panelHeight;
```

**External names stay as they are.** A name that a platform SDK or a library declares is
not a name of this codebase. Use it as the SDK spells it: `kFSEventStreamEventFlagItemModified`,
`FILE_NOTIFY_CHANGE_SIZE`, `IN_CLOSE_WRITE`. The rules of this document apply to the names
that this codebase declares.

---

## Rule 3 — Semantic over literal

**Principle:**  
Semantic naming involves choosing names that clearly and accurately convey the purpose and meaning of the data they hold, rather than just their type or how they were obtained.

**Rationale:**  
Code is an expression of ideas. A name should clearly communicate its purpose, intention, or role within its specific context and scope. Semantic names prevent bugs by revealing intent—literal names hide meaning and force readers to reverse-engineer what code does. When you name things by what they *mean* rather than what they *are*, you make the invisible visible.

**Examples:**

**Bad:**
```cpp
juce::File getUserSettings(juce::XmlElement* defaultSettings = nullptr);
// "getUserSettings" suggests retrieval only, but the function actually 
// creates the file if missing and writes default values.

const juce::File getFactoryDefaultPresetsDirectory(const juce::String& versionString);
// Function creates directories if they don't exist—"get" implies pure retrieval.

std::unique_ptr<juce::XmlElement> xml;
// "xml" describes the format/container, not what the data represents.
```

**Good:**
```cpp
juce::File getOrCreateUserSettings(juce::XmlElement* defaultSettings = nullptr);
// Name reveals the function creates the file when needed, not just retrieves it.

const juce::File getOrCreateFactoryPresetsDirectory(const juce::String& versionString);
// "getOrCreate" accurately describes the side effect of directory creation.

std::unique_ptr<juce::XmlElement> layout;
// "layout" describes the semantic meaning—a UI layout structure.

std::unique_ptr<juce::XmlElement> presetData;
// "presetData" tells you what the content represents, not just that it's XML.
```

**Key practices:**

- **Describe the content, not the container:** A variable named `layout` is more semantic than `xmlElement` or `xmlData`, as it tells you what the XML represents.

- **Be specific and precise:** Instead of `getUserSettings()`, use `getOrCreateUserSettings()` when the function has side effects. This prevents bugs where callers assume the function is read-only.

- **Boolean variables:** Name boolean variables to reflect the condition they represent, such as `isPresetDirty`, `shouldPromptLicense`, or `isEvaluating`.

---

## Rule 4 — Clarity over brevity

**Principle:**  
Longer descriptive names are unambiguous and self-documented, potentially reducing unnecessary comments.

**Rationale:**  
Compilers don't care how long or short your variables and functions are named. If everything is legal and sane, it will work. But when it doesn't, humans need to read, review, and debug. Short names might be easier to type, but adding extra comments to explain them just adds noise and pollutes the codebase.

**Examples:**

**Bad:**
```cpp
// Unclear scope and purpose
void build(juce::Component* view, 
           Descriptors& descriptors,
           Registry& registry);

// Vague about what's being set
void setValue(const juce::String& newValue);

// Hidden side effect—function also validates and may throw
juce::File getSettings();
```

**Good:**
```cpp
// Explicit about the complete operation
void buildAndAttachComponents(juce::Component* parentView,
                              Descriptors& componentDescriptors,
                              Registry& componentRegistry,
                              Model& dataModel);

// Clear about which scale value
void setUIscale(const juce::String& newScaleValue);

// Reveals the side effect in the name
juce::File getOrCreateUserSettings(juce::XmlElement* defaultSettings = nullptr);

// Parameters clarify their domain context
const juce::File getFactoryDefaultPresetsDirectory(const juce::String& versionString) const noexcept;
const juce::File getUserPresetsDirectory() const noexcept;
```

**Real consequence:**
```cpp
// BAD: Hides critical behavior
void loadPreset(const juce::File& file);
// Reader assumes this is safe to call anytime.
// Actually silently fails if preset is dirty!

// GOOD: Name reveals the precondition
void loadPresetIfNotDirty(const juce::File& file);
// Or better, be explicit in implementation:
if (isPresetDirty()) return; // Now readers see the guard
```

---

## When to Bend the Rules

These rules are tools, not laws. There are legitimate cases where bending them produces clearer code:

**Domain-specific context:**
```cpp
class Model : public juce::AudioProcessorValueTreeState
{
    // "Model" bends Rule 2 (it's technically an APVTS wrapper)
    // BUT: Within an MVC architecture, "Model" is semantically correct
    // for its role, even though the type is 40+ characters long.
    // Context matters—inside your namespace and architecture,
    // this name is more meaningful than "AudioProcessorValueTreeState".
};
```

**Established conventions:**
```cpp
// Loop counters in small scopes
for (int i = 0; i < items.size(); ++i)
{
    process(items[i]);
}

// Standard abbreviations when universally understood
juce::XmlElement* xml;  // Not "xmlDocument"—context is clear
juce::String id;        // Not "identifier"—too verbose for ubiquitous use
const juce::String& url; // Domain abbreviation, widely understood
```

**Scope-dependent brevity:**
```cpp
// Short scope: brevity acceptable
auto isValid = [&](const auto& x) { return x.isNotEmpty(); };

// Class member: clarity required
class Manager
{
    bool isUsingWhitespace;  // Not "flag" or "b"
};
```

**When bending a rule, ask:**
- Does this name's meaning remain clear within its scope?
- Would a longer name add noise without adding clarity?
- Is this convention universally understood by the team?

If you can't answer "yes" to all three, follow the rules.

---

## Rule 5 — Consistency

**Principle:**  
Applying the above rules holistically across the codebase will guarantee identical self-documented patterns linguistically and semantically. When the same concept appears in different parts of the code, it should use the same naming convention. If you use `get` for retrieval in one place, don't switch to `fetch` or `retrieve` elsewhere. If collections are plural, keep them plural throughout.

**Rationale:**  
A consistent codebase is easier to read, understand, and maintain. Consistency creates predictability—developers can form reliable mental models about how the code works. When patterns repeat uniformly, new team members onboard faster, bugs become easier to spot, and refactoring becomes safer. Inconsistency forces readers to question whether differences in naming indicate differences in behavior, adding unnecessary cognitive load. Consistency transforms a collection of files into a cohesive system.

**Examples:**

**Inconsistent patterns:**
```cpp
// Mixing verb forms for similar operations
juce::String getProductName() const noexcept;
juce::String fetchVersionString() const noexcept;
juce::String retrieveProductWebsite() const noexcept;

// Inconsistent parameter naming
void setImages(juce::Component* view, Descriptors& descriptors);
void setRules(juce::Component* comp, Descriptors& desc);
void attachTo(juce::Component* parent, Descriptors& componentDescriptors);

// Mixed naming for boolean checks
bool isPresetDirty() const noexcept;
bool shouldPromptLicense() const noexcept;
bool checkIfEvaluating() const noexcept;  // Inconsistent with is/should pattern
```

**Consistent patterns:**
```cpp
// Uniform verb form for getters
juce::String getProductName() const noexcept;
juce::String getVersionString() const noexcept;
juce::String getProductWebsite() const noexcept;

// Consistent parameter naming throughout Manager
void setImages(juce::Component* view, Descriptors& descriptors);
void setRules(juce::Component* view, Descriptors& descriptors);
void attachTo(juce::Component* view, Descriptors& descriptors);

// Consistent boolean naming pattern
bool isPresetDirty() const noexcept;
bool isEvaluating() const noexcept;
bool shouldPromptLicense() const noexcept;
```

**Nearest-sibling precedence.**
When a new member joins an existing family — a class's reader set, a module's `add*`
family, a file's dispatch tables — the family's established shape outranks any
independently better name. Consistency is measured against the nearest surrounding
set first, the module second, the framework third.

**Rationale:**
A name that is locally better but breaks its family costs every future reader a lookup
to confirm the two members really do differ. The family shape is itself documentation.

**Example:**

```cpp
// Existing family on Css::StyleDeclaration
juce::String getPropertyValue (juce::StringRef) const;
juce::String getPropertyPriority (juce::StringRef) const;

// CORRECT — joins the family
int getPropertyType (juce::StringRef) const;

// WRONG — locally defensible (it reads Token::type), breaks the family
int getType (juce::StringRef) const;
```

---

## Rule 6 — Forbidden Terms

Certain names are banned because they are vague, borrowed from the wrong domain,
or carry no semantic content. Use the exact semantic purpose instead.

| Banned | Use instead | Rationale |
|--------|-------------|-----------|
| `graft` | `attach` | Botanical metaphor — not a software concept |
| `node` | the actual tree type name | Exposes implementation detail, not domain meaning |
| `seed` | *(banned outright)* | No defined meaning in this codebase |
| `handler` | `callbacks`, `events`, `parameters`, or the exact dispatch purpose | Says nothing about *what* is handled — name the contract, not the mechanism |
| `kind` | `Type` | `Type` is canonical throughout the codebase — `kind` creates ambiguity with no semantic distinction |
| `resolve` | `get`, `set`, `find`, `isSomething`, `hasSomething`, or the exact direct action | Indirect/ambiguous — signals an obfuscated mental model or unclear design, not a real operation |
| `ensure` | `get`, `getOrCreate`, `cache`, or the exact unconditional action | Concedes the precondition might not hold — pessimistic by construction; the invariant belongs at the owner, asserted once, not re-doubted at every call site |
| `emitter` | the produced thing (plain noun), or the real operation | Names the mechanism, not the contract — `handler`'s twin |

**The agent-noun test.**
A name ending in `-er` / `-ers` is permitted only when it performs a **real, named
operation** that exists in the domain vocabulary. If the `-er` names a mechanism rather
than a contract — *the thing that does the thing* — it is banned by the same reasoning
that bans `handler`.

| Candidate | Verdict | Why |
|---|---|---|
| `serializers` | permitted | serialization is a real named operation |
| `fetchers` | permitted | fetching is a real named operation |
| `emitters` | **banned** | "emit" names no operation in this domain — mechanism, not contract |
| `handler` | **banned** *(already listed)* | says nothing about what is handled |
| `manager` | case-by-case | permitted only where the managed domain is in the name (`StyleManager`, `ParameterManager`) |

---

## Rule 7 — Boundary Naming: name the output domain

**Principle:**
A unit that consumes vocabulary from domain A to produce vocabulary in domain B is named
in **B's** terms — what it yields, never what it is keyed by or reads from.

**Rationale:**
Callers reach for a name by what they want out of it. Naming by the input or the key
forces the reader to know the implementation before they can find the symbol, which
inverts Rule 3 (semantic over literal): the key is an implementation fact, the output is
the meaning.

**Example:**

```cpp
// Css: keyed by Id::CssTokenType ordinal, named for the attribute it yields
static const auto attributeSerializers { ... };   // inside getStringAttribute

// Html: keyed by the same ordinal, yields element attributes on a style element
static const auto styleAttributes { ... };        // inside addStyleAttributes

// WRONG — names the key, not the product
static const auto tokenTypeMap { ... };
```

Corollary: where the two domains have competing words for the same slot — CSS calls it a
`property`, an element calls it an `attribute` — the containing function's own name
settles it. `addStyleAttributes` yields attributes, so its table is named for attributes.

---

## Rule 8 — Dispatch Tables Are Nouns

**Principle:**
A lookup table replacing a branch chain (`kuassa::Function::Map` and equivalents) is named
either as a plain noun for **what the table holds**, or as a verb-noun for **what it
drives**. Never as an agent plural.

**Rationale:**
MANIFESTO L's 3-branch rule makes these tables the standard replacement for decision
chains, so they now appear in every module — an unstated convention would drift within one
sprint. The table is data; data takes noun names (Rule 1).

**Examples:**

```cpp
// Plain noun — what the table holds
static const auto selectors { ... };
static const auto markupOperators { ... };
static const auto styleAttributes { ... };

// Verb-noun — what the table drives
static const auto treeConstruction { ... };

// WRONG — agent plural (Rule 6 agent-noun test)
static const auto valueEmitters { ... };
static const auto tokenHandlers { ... };
```
