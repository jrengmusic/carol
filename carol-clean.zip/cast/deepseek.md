## permission member

| key           | value               |
| ------------- | ------------------- |
| `defaultMode` | `bypassPermissions` |

## member

| key                                 | value |
| ----------------------------------- | ----- |
| `skipDangerousModePermissionPrompt` | true  |

## env

| key                                        | value                                |
| ------------------------------------------ | ------------------------------------ |
| `ANTHROPIC_BASE_URL`                       | `https://api.deepseek.com/anthropic` |
| `API_TIMEOUT_MS`                           | `3000000`                            |
| `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC` | `1`                                  |
| `CLAUDE_CODE_EFFORT_LEVEL`                 | `MAX`                                |
| `ANTHROPIC_DEFAULT_OPUS_MODEL`             | `deepseek-v4-pro[1m]`                |
| `ANTHROPIC_DEFAULT_SONNET_MODEL`           | `deepseek-v4-flash`                  |
| `ANTHROPIC_DEFAULT_HAIKU_MODEL`            | `deepseek-v4-flash`                  |
| `CAROL_CONTEXT_FILL_PERCENT`               | `90`                                 |
| `CAROL_CONTEXT_DIVISOR`                    | `1000000`                            |
| `BASH_MAX_TIMEOUT_MS`                      | `900000`                             |
