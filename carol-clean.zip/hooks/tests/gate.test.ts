import { expect, mock, test } from 'claude-code/testing'
import cases from './cases'

const ROOT = '/carol-root'
const ALLOWED_RESULT = 'ALLOWED'
const USER_ORIGIN_KIND = 'composer'
const ARMED_AT_MS = 1000
const ROLE_FILE = ROOT + '/.carol-role'
const SUBAGENT_ID = 'sub1'
const DEFAULT_SUBAGENT_TYPE = 'Engineer'

const definitions = new Map<string, string>([
  [ROOT + '/agents/pathfinder.md', '---\nname: Pathfinder\nmodel: haiku\n---\n'],
  [ROOT + '/agents/engineer.md', '---\nname: Engineer\nmodel: sonnet\n---\n'],
  [ROOT + '/agents/auditor.md', '---\nname: Auditor\nmodel: opus\n---\n'],
])

function getToolInput(testCase: any) {
  if (testCase.tool === 'Bash') {
    return {
      tool: 'Bash',
      command: testCase.command,
      ...(testCase.subagent ? { agentId: SUBAGENT_ID } : {}),
      ...(testCase.background ? { run_in_background: true } : {}),
    }
  }
  if (testCase.tool === 'Monitor') {
    return { tool: 'Monitor', command: testCase.command, ...(testCase.subagent ? { agentId: SUBAGENT_ID } : {}) }
  }
  if (testCase.tool === 'Agent') {
    return { tool: 'Agent', subagent_type: testCase.subagentType, ...(testCase.model ? { model: testCase.model } : {}) }
  }
  return { tool: testCase.tool, questions: [] }
}

for (const testCase of cases as any[]) {
  test(testCase.name, async ($, on) => {
    mock.clock(on, { now: ARMED_AT_MS })
    mock.env(on, { CAROL_ROOT: ROOT, ...(testCase.role ? { CAROL_ROLE: testCase.role } : {}) })
    const files = new Map(definitions)
    if (testCase.roleFile !== undefined) files.set(ROLE_FILE, testCase.roleFile)
    on('fs.exists', ($, e) => ({ value: files.has(e.path) }))
    on('fs.read', ($, e) => ({ value: files.get(e.path) }))
    on('classic.UserPromptSubmit', () => ({}))
    on('agent.list', () => ({ value: [{ id: SUBAGENT_ID, type: testCase.subagentType ?? DEFAULT_SUBAGENT_TYPE, description: testCase.subagentDescription ?? '' }] }) as any)
    let lastContext: string[] | undefined
    on('prompt.submit', ($, e) => {
      lastContext = e.context
      return { text: e.text }
    })
    on('tool.call', ($, e) => testCase.toolOutcomes?.[e.tool] ?? { result: ALLOWED_RESULT })

    const submitPrompt = async (prompt: any) => {
      const text = typeof prompt === 'string' ? prompt : prompt.text
      const originKind = typeof prompt === 'string' ? USER_ORIGIN_KIND : prompt.origin
      lastContext = undefined
      await $.classic.UserPromptSubmit({ session_id: 't', hook_event_name: 'UserPromptSubmit', prompt: text, agent_type: testCase.agentType ?? '' })
      await $.prompt.submit({ text, wait: false, origin: { kind: originKind } })
    }

    for (const prompt of testCase.prompts) {
      await submitPrompt(prompt)
    }

    for (const contractRead of testCase.reads ?? []) {
      await $.tool.call(typeof contractRead === 'string' ? { tool: 'Read', file_path: contractRead } : { tool: 'Read', ...contractRead })
    }

    for (const prompt of testCase.promptsAfterReads ?? []) {
      await submitPrompt(prompt)
    }

    for (const priorTool of testCase.priorTools ?? []) {
      await $.tool.call({ tool: priorTool, questions: [] })
    }

    const outcome: any = await $.tool.call(getToolInput(testCase))
    expect(outcome.deny === undefined ? 'allow' : 'deny').toBe(testCase.expect)
    if (testCase.contextLinesOnLastPrompt !== undefined) {
      expect((lastContext ?? []).length).toBe(testCase.contextLinesOnLastPrompt)
    }
  })
}
